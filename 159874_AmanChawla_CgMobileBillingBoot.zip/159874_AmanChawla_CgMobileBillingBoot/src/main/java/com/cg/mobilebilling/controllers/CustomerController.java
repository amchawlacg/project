package com.cg.mobilebilling.controllers;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.PostpaidAccountDAO;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
import com.cg.mobilebilling.services.GeneratePdfReport;
import com.itextpdf.text.DocumentException;

@Controller
public class CustomerController {
	@Autowired 
	BillingServices service;
	Customer cust;
	PostpaidAccount account,account1;
	Bill bill2;
	int amount;

	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomerAction(@Valid@ModelAttribute Customer customer,BindingResult result) throws BillingServicesDownException {
		if(result.hasErrors()) {
			String errorMsg = "Enter correct details";
			return new ModelAndView("registrationPage","errMsg",errorMsg);
		}
		else {
			int customerID=	service.acceptCustomerDetails(customer.getFirstName(), customer.getLastName(), customer.getEmailID(),customer.getDateOfBirth(),customer.getBillingAddress().getCity(), customer.getBillingAddress().getState(), customer.getBillingAddress().getPinCode());
			cust = customer;
			cust.setCustomerID(customerID);
			return new ModelAndView("registrationSuccessPage", "customer", customer);
		}
	}
	@RequestMapping("/deleteCustomer")
	public ModelAndView deleteCustomerAction(@ModelAttribute Customer customer) throws BillingServicesDownException, CustomerDetailsNotFoundException {
		try{
			service.deleteCustomer(customer.getCustomerID());}
		catch (Exception e) {
			String errorMsg = "Customer does not exist";
			return new ModelAndView("deleteCustomerPage","errMsg",errorMsg);
		}
		return new ModelAndView("deletionSuccessPage");

	}
	@RequestMapping("/deleteAccount")
	public ModelAndView deleteAccountAction(@ModelAttribute PostpaidAccount account) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException   {
		try{service.closeCustomerPostPaidAccount(-1,account.getMobileNo());}
		catch (Exception e) {
			String errorMsg = "Account does not exist";
			return new ModelAndView("deleteAccountPage","errMsg",errorMsg);
		}
		return new ModelAndView("deletionSuccessPage");

	}


	@RequestMapping("/viewBillMethod")
	public ModelAndView viewBillAction(@ModelAttribute Bill bill , HttpServletRequest request) throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		try{
			bill=service.getMobileBillDetails(-1, bill.getPostpaidAccount().getMobileNo(), bill.getBillMonth());
		}
		catch (Exception e) {
			String errormsg = "Enter correct details";
			return new ModelAndView("viewBillsPage","errMsg",errormsg);
		}
		return new ModelAndView("showBillPage","bill",bill);

	}

	@RequestMapping("/registerPlan")     //sign up
	public ModelAndView registerPlanAction(@ModelAttribute Plan plan,HttpServletRequest request) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		long mobileNo = service.openPostpaidMobileAccount(cust.getCustomerID(), plan.getPlanID());
		account = service.getPostPaidAccountDetails(cust.getCustomerID(), mobileNo);
		request.getSession().setAttribute("account1", account);
		return new ModelAndView("planRegistrationSuccessPage", "account", service.getPostPaidAccountDetails(cust.getCustomerID(), mobileNo));

	}
	@RequestMapping("/anotherConnection")
	public ModelAndView registerAnotherConnectionAction(@ModelAttribute Plan plan,HttpServletRequest request) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		try {Customer customer=((PostpaidAccount)request.getSession().getAttribute("account")).getCustomer();
		long mobileNo =service.openPostpaidMobileAccount(customer.getCustomerID(), plan.getPlanID()) ;
		request.getSession().removeAttribute("account");
		account = service.getPostPaidAccountDetails(customer.getCustomerID(), mobileNo);
		request.getSession().setAttribute("account", account);

		} catch (Exception e) {
			return new ModelAndView("newConnectionPlanRegistrationPage");
		}
		return new ModelAndView("newConnectionSuccessPage", "account", account);
	}

	@RequestMapping("/loginCustomer")
	public ModelAndView loginCustomerAction(@RequestParam("mobileNo") long mobileNo,HttpServletRequest request,HttpServletResponse response) throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, IOException {
		try {
			account1 = service.getPostPaidAccountDetails(0, mobileNo);
		} catch (Exception e) {
			String errorMsg="Enter Correct Mobile Number";
			return new ModelAndView("loginPage","errMsg",errorMsg);
		}
		request.getSession().setAttribute("account", account1);
		return new ModelAndView("loginSuccessPage");
	}

	@RequestMapping("/loginRegisterPlan")
	public ModelAndView loginRegisterPlanAction(@ModelAttribute Plan plan,HttpServletRequest request) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		PostpaidAccount loginAccount = (PostpaidAccount) request.getSession().getAttribute("account");
		service.changePlan(0, loginAccount.getMobileNo(), plan.getPlanID());
		loginAccount = service.getPostPaidAccountDetails(0, loginAccount.getMobileNo());
		return new ModelAndView("loginPlanRegistrationSuccessPage", "account1", loginAccount);

	}

	@RequestMapping("/generate")
	public ModelAndView generateBillAction(@Valid @ModelAttribute Bill bill,HttpServletRequest request) throws  InvalidBillMonthException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException {
		PostpaidAccount loginAccount = (PostpaidAccount) request.getSession().getAttribute("account1");
		bill2 = service.generateMonthlyMobileBill(loginAccount.getCustomer().getCustomerID(), loginAccount.getMobileNo(), bill.getBillMonth(), bill.getNoOfLocalSMS(), bill.getNoOfStdSMS(), bill.getNoOfLocalCalls(), bill.getNoOfStdCalls(), bill.getInternetDataUsageUnits());
		return new ModelAndView("billGenerated", "bill", bill2);
	}

	@RequestMapping("/loginGenerateBill")
	public ModelAndView loginGenerateBillAction(@Valid @ModelAttribute Bill bill,HttpServletRequest request) throws  InvalidBillMonthException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException {
		PostpaidAccount demoAccount=(PostpaidAccount) request.getSession().getAttribute("account");
		bill2 = service.generateMonthlyMobileBill(demoAccount.getCustomer().getCustomerID(),
				demoAccount.getMobileNo(),
				bill.getBillMonth(), bill.getNoOfLocalSMS(), bill.getNoOfStdSMS(), bill.getNoOfLocalCalls(), bill.getNoOfStdCalls(), bill.getInternetDataUsageUnits());
		//bill2.setPostpaidAccount(service.getPostPaidAccountDetails(-1, demoAccount.getMobileNo()));
		return new ModelAndView("billGenerated", "bill", bill2);	
	}
	@RequestMapping(value = "/allBillsPdfReport", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_PDF_VALUE )
    public ResponseEntity<InputStreamResource> getAllBillsPdfReport(@RequestParam("customerID")int customerID,@RequestParam("mobileNo")long mobileNo) throws IOException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, BillDetailsNotFoundException, PlanDetailsNotFoundException, DocumentException {

        List<Bill> bills =  service.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo);

        ByteArrayInputStream bis = GeneratePdfReport.billsReport(bills);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "inline; filename=billsreport.pdf");

        return ResponseEntity
                .ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(bis));
    }
	@RequestMapping("/displayCustomerPostPaidAccountAllBillDetails")
	public ModelAndView getDisplayCustomerPostPaidAccountAllBillDetails(@RequestParam("customerID")int customerID,@RequestParam("mobileNo")long mobileNo)  {
		List<Bill> bills;
		try {
			bills = service.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo);
		} catch (CustomerDetailsNotFoundException e) {
			return new ModelAndView("adminPage", "errMsg", "Customer Not Found!!!!!Please Register");
		} catch (PostpaidAccountNotFoundException e) {
			return new ModelAndView("adminPage", "errMsg", "Invalid Mobile Number!!!!!Please Try Again");
		} catch (BillingServicesDownException e) {
			return new ModelAndView("adminPage", "errMsg", "Error Occured!!!!!Please Try Again");
		} catch (PlanDetailsNotFoundException e) {
			return new ModelAndView("adminPage", "errMsg", "Invalid Plan!!!!!Please Try Again");
		} catch (BillDetailsNotFoundException e) {
			return new ModelAndView("adminPage", "errMsg", "Bill Unavailable!!!!!Please Try Again");
		}
		return new ModelAndView("displayAllBillsPage", "bills", bills);
	}
	

}