package com.cg.mobilebilling.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.mobilebilling.beans.Customer;

public interface CustomerDAO extends JpaRepository<Customer, Integer> {

	@Query(value="delete from customer where customerID=?1",nativeQuery=true)
	public void removeCustomer(int customerID);
}
