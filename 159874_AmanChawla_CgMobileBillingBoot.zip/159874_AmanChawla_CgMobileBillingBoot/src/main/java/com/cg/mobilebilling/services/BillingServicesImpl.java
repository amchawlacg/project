package com.cg.mobilebilling.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.CustomerDAO;
import com.cg.mobilebilling.daoservices.PlanDAO;
import com.cg.mobilebilling.daoservices.PostpaidAccountDAO;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;

@Component("service")
public class BillingServicesImpl implements BillingServices {

	@Autowired
	BillingDAOServices billingDAOServices;
	@Autowired
	PlanDAO planDAO;
	@Autowired
	CustomerDAO customerDAO;
	@Autowired
	PostpaidAccountDAO postpaidAccountDAO;

	PostpaidAccount account1;
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		List<Plan> planList = planDAO.findAll();
		return planList;

	}

	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailID, String dateOfBirth,
			String billingAddressCity, String billingAddressState, int billingAddressPinCode)
					throws BillingServicesDownException {
		Customer customer = new Customer(firstName, lastName, emailID, dateOfBirth, 
				new Address(billingAddressPinCode, billingAddressCity, billingAddressState));
		customer = customerDAO.save(customer);
		return customer.getCustomerID();

	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {

		Plan plan1 = new Plan(147, 250, 200, 150, 500, 500, 1024, 1.0f, 1.50f, 1.0f, 2.0f, 0.10f, "GOA", "G250");
		plan1= planDAO.save(plan1);
		Plan plan2 = new Plan(158, 250, 300, 200, 500, 300, 1024, 1.0f, 1.50f, 1.0f, 2.0f, 0.10f, "GOA", "G200");
		plan2 = planDAO.save(plan2);
		Plan plan3 = new Plan(163, 400, 250, 250, 800, 500, 2048, 1.0f, 1.50f, 1.0f, 2.0f, 0.10f, "GOA", "G350");
		plan3 = planDAO.save(plan3);
		Plan plan4 = new Plan(189, 600, 800, 600, 800, 500, 5120, 1.0f, 1.50f, 1.0f, 2.0f, 0.10f, "GOA", "G450");
		plan4 = planDAO.save(plan4);
		PostpaidAccount account = new PostpaidAccount();
		account.setPlan(planDAO.findById(planID).orElseThrow(()->new PlanDetailsNotFoundException()));
		account.setCustomer(customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException()));
		PostpaidAccount postpaidAccount = postpaidAccountDAO.save(account);
		account1=account;
		return postpaidAccount.getMobileNo();
	}


	public Bill generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
					throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
					BillingServicesDownException, PlanDetailsNotFoundException {
		Plan plan ;
		plan = postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException()).getPlan();
		Bill bill1= new Bill();
		int localCalls=noOfLocalCalls-plan.getFreeLocalCalls();
		int stdCalls=noOfStdCalls-plan.getFreeStdCalls();
		int localSMS = noOfLocalSMS-plan.getFreeLocalSMS();
		int stdSMS=noOfStdSMS-plan.getFreeStdSMS();
		int internetUnits=internetDataUsageUnits-plan.getFreeInternetDataUsageUnits();

		bill1.setNoOfLocalCalls(noOfLocalCalls);
		bill1.setNoOfLocalSMS(noOfLocalSMS);
		bill1.setNoOfStdCalls(noOfStdCalls);
		bill1.setNoOfStdSMS(noOfStdSMS);
		bill1.setBillMonth(billMonth);
		bill1.setInternetDataUsageUnits(internetDataUsageUnits);
		bill1.setLocalCallAmount(localCalls>0?localCalls:0);
		bill1.setStdCallAmount(stdCalls>0?stdCalls*2:0);
		bill1.setStdSMSAmount(stdSMS>0?stdSMS*2:0);
		bill1.setLocalSMSAmount(localSMS>0?localSMS:0);
		bill1.setInternetDataUsageAmount(internetUnits>0?internetUnits:0);
		double billAmount = plan.getMonthlyRental()+bill1.getInternetDataUsageAmount()+bill1.getLocalCallAmount()+bill1.getStdCallAmount()+bill1.getLocalSMSAmount()+bill1.getStdSMSAmount();
		bill1.setTotalBillAmount((float)billAmount);
		bill1.setPostpaidAccount(getPostPaidAccountDetails(customerID, mobileNo));
		billingDAOServices.save(bill1);
		return bill1;
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer = customerDAO.findById(customerID).orElseThrow(()->new BillingServicesDownException());
		return customer;

	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		List<Customer> customers = customerDAO.findAll();
		return customers;

	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		PostpaidAccount account = postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException());	
		if(account==null) throw new PostpaidAccountNotFoundException();
		return account;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		return null;
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException,  BillingServicesDownException {
		List<Bill> bills = postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException()).getBills();
		for (Bill bill : bills) {
			if(bill.getBillMonth().equals(billMonth))
				return bill;
		}
		return null;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException, PlanDetailsNotFoundException {
		customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PlanDetailsNotFoundException("Postpaid Account not found"));
		List<Bill> bills=billingDAOServices.getCustomerPostPaidAccountAllBills(mobileNo);
		if(bills==null)
			throw new BillDetailsNotFoundException("Bill not found");
		return bills;

	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
	PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		PostpaidAccount postpaidAccount = postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException());
		Plan plan = planDAO.findById(planID).orElseThrow(()->new PlanDetailsNotFoundException());
		postpaidAccount.setPlan(plan);
		postpaidAccountDAO.save(postpaidAccount);
		return false;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		PostpaidAccount account = postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException());
		postpaidAccountDAO.deleteAccount(mobileNo);
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException());
		customerDAO.deleteById(customerID);
		return false;
	}




}